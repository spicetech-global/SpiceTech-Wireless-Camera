# v0.1.1

- Set Windows PowerShell HTTPS requests to TLS 1.2 before contacting GitHub.
- Kept normal certificate-chain validation enabled; no certificate checks are bypassed.
- This addresses older Windows PowerShell defaults but does not repair an incorrect system clock, missing trusted root certificates, or HTTPS inspection by security software/proxies.
