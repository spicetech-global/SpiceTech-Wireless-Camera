# SpiceTech Wireless Camera - lightweight Windows companion (PowerShell/WinForms)
# First launch downloads the official MediaMTX Windows x64 release. Thereafter streaming is LAN-only.
$ErrorActionPreference = 'Stop'
# Use TLS 1.2 for GitHub's HTTPS endpoints on Windows PowerShell 5.1.
# Certificate validation remains enabled; never bypass TLS trust checks.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$root = Split-Path -Parent $PSScriptRoot
$gatewayDir = Join-Path $root 'gateway'
$exe = Join-Path $gatewayDir 'mediamtx.exe'
$config = Join-Path $gatewayDir 'mediamtx.yml'
$log = Join-Path $gatewayDir 'mediamtx.log'
$script:gatewayProcess = $null

function Get-LanIPv4 {
  $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.AddressState -eq 'Preferred' }
  return @($ips | ForEach-Object { $_.IPAddress } | Select-Object -Unique)
}
function Ensure-Gateway {
  if (Test-Path $exe) { return }
  $label.Text = 'Downloading official MediaMTX gateway (one-time setup)…'
  $form.Refresh()
  $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/bluenviron/mediamtx/releases/latest' -Headers @{ 'User-Agent'='SpiceTech-Wireless-Camera' }
  $asset = $release.assets | Where-Object { $_.name -match 'windows_amd64\.zip$' } | Select-Object -First 1
  if (-not $asset) { throw 'Could not find the official MediaMTX Windows x64 package.' }
  $zip = Join-Path $env:TEMP 'spicetech-mediamtx.zip'
  Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zip
  $unpack = Join-Path $env:TEMP 'spicetech-mediamtx-unpack'
  if (Test-Path $unpack) { Remove-Item $unpack -Recurse -Force }
  Expand-Archive -Path $zip -DestinationPath $unpack -Force
  $binary = Get-ChildItem $unpack -Filter 'mediamtx.exe' -Recurse | Select-Object -First 1
  if (-not $binary) { throw 'MediaMTX executable was not present in the downloaded archive.' }
  Copy-Item $binary.FullName $exe -Force
  Remove-Item $unpack -Recurse -Force
  Remove-Item $zip -Force
}
function Start-Gateway {
  Ensure-Gateway
  if ($script:gatewayProcess -and -not $script:gatewayProcess.HasExited) { return }
  $script:gatewayProcess = Start-Process -FilePath $exe -ArgumentList @($config) -WorkingDirectory $gatewayDir -RedirectStandardOutput $log -RedirectStandardError ($log + '.err') -PassThru -WindowStyle Hidden
  Start-Sleep -Milliseconds 700
  if ($script:gatewayProcess.HasExited) { throw "Gateway stopped during startup. Check $log" }
  $label.Text = 'Gateway running. Connect phones on the same Wi-Fi network.'
  $startButton.Enabled = $false; $stopButton.Enabled = $true
}
function Stop-Gateway {
  if ($script:gatewayProcess -and -not $script:gatewayProcess.HasExited) { Stop-Process -Id $script:gatewayProcess.Id -Force }
  $script:gatewayProcess = $null
  $label.Text = 'Gateway stopped.'
  $startButton.Enabled = $true; $stopButton.Enabled = $false
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'SpiceTech Wireless Camera'
$form.Size = New-Object System.Drawing.Size(650,480)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [Drawing.Color]::FromArgb(24,24,24)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font('Segoe UI',10)
$title = New-Object Windows.Forms.Label; $title.Text='SPICETECH WIRELESS CAMERA'; $title.Font=New-Object Drawing.Font('Segoe UI',17,[Drawing.FontStyle]::Bold); $title.ForeColor=[Drawing.Color]::FromArgb(218,174,55); $title.SetBounds(22,18,580,38); $form.Controls.Add($title)
$label = New-Object Windows.Forms.Label; $label.Text='Ready. Start the gateway, then connect your phone to this laptop Wi-Fi.'; $label.SetBounds(24,65,590,42); $form.Controls.Add($label)
$startButton = New-Object Windows.Forms.Button; $startButton.Text='START GATEWAY'; $startButton.SetBounds(24,116,180,42); $form.Controls.Add($startButton)
$stopButton = New-Object Windows.Forms.Button; $stopButton.Text='STOP GATEWAY'; $stopButton.SetBounds(216,116,180,42); $stopButton.Enabled=$false; $form.Controls.Add($stopButton)
$refreshButton = New-Object Windows.Forms.Button; $refreshButton.Text='REFRESH IP'; $refreshButton.SetBounds(408,116,180,42); $form.Controls.Add($refreshButton)
$ipTitle = New-Object Windows.Forms.Label; $ipTitle.Text='THIS LAPTOP — IPv4 ADDRESS'; $ipTitle.ForeColor=[Drawing.Color]::FromArgb(218,174,55); $ipTitle.SetBounds(24,180,570,24); $form.Controls.Add($ipTitle)
$ipBox = New-Object Windows.Forms.ListBox; $ipBox.SetBounds(24,208,570,68); $ipBox.Font=New-Object Drawing.Font('Consolas',12); $form.Controls.Add($ipBox)
$urlTitle = New-Object Windows.Forms.Label; $urlTitle.Text='CAMERA STREAM URLS — copy the matching address into OBS/vMix'; $urlTitle.SetBounds(24,292,590,24); $form.Controls.Add($urlTitle)
$urlBox = New-Object Windows.Forms.ListBox; $urlBox.SetBounds(24,320,570,72); $urlBox.Font=New-Object Drawing.Font('Consolas',10); $form.Controls.Add($urlBox)
$copyButton = New-Object Windows.Forms.Button; $copyButton.Text='COPY SELECTED RTSP URL'; $copyButton.SetBounds(24,398,230,34); $form.Controls.Add($copyButton)
$refresh = {
  $ipBox.Items.Clear(); $ips = @(Get-LanIPv4)
  foreach ($ip in $ips) { [void]$ipBox.Items.Add($ip) }
  if ($ips.Count -eq 0) { [void]$ipBox.Items.Add('No Wi-Fi/LAN IPv4 address found. Connect to a local network.') }
  $urlBox.Items.Clear()
  foreach ($ip in $ips) { foreach ($cam in 1..4) { [void]$urlBox.Items.Add("rtsp://${ip}:8554/cam${cam}") } }
}
$startButton.Add_Click({ try { Start-Gateway } catch { [Windows.Forms.MessageBox]::Show($_.Exception.Message,'SpiceTech Gateway Error','OK','Error') } })
$stopButton.Add_Click({ Stop-Gateway })
$refreshButton.Add_Click($refresh)
$copyButton.Add_Click({ if ($urlBox.SelectedItem) { [Windows.Forms.Clipboard]::SetText([string]$urlBox.SelectedItem); $label.Text='RTSP URL copied.' } })
$form.Add_FormClosing({ Stop-Gateway })
& $refresh
[void]$form.ShowDialog()
