@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SpiceTech-Companion.ps1"
