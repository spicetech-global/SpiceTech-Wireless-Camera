# Run in an elevated PowerShell window only if Windows Firewall blocks the gateway.
# Adds narrow inbound TCP rules on Private networks, scoped to the local subnet.
# Does not disable Windows Firewall or open ports on Public networks.
$ErrorActionPreference = 'Stop'
$rules = @(
  @{ Name='SpiceTech Wireless Camera - RTMP'; Port=1935; Description='Phone video publisher to local MediaMTX gateway' },
  @{ Name='SpiceTech Wireless Camera - RTSP'; Port=8554; Description='OBS/vMix RTSP reader from local MediaMTX gateway' }
)
foreach ($r in $rules) {
  if (-not (Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $r.Name -Direction Inbound -Action Allow -Protocol TCP -LocalPort $r.Port -Profile Private -RemoteAddress LocalSubnet -Description $r.Description | Out-Null
  }
}
Write-Host 'Private-network-only SpiceTech firewall rules installed.'
