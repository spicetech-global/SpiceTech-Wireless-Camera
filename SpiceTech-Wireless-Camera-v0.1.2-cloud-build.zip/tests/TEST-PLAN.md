# Hardware acceptance test plan

Record device model, Android version, Windows edition/build, Wi-Fi access point, OBS/vMix versions, and test date.

- [ ] Android 11 permission prompt and preview.
- [ ] Start RTMP publish to Windows private-LAN IPv4.
- [ ] Confirm MediaMTX logs show publisher on `/cam1`.
- [ ] Confirm VLC can read `rtsp://WINDOWS-IP:8554/cam1` over RTSP/TCP.
- [ ] Confirm OBS Media Source / VLC Video Source can display the RTSP feed (record OBS version and source type).
- [ ] Confirm vMix Stream input can display RTSP over TCP (record vMix version).
- [ ] Disconnect/reconnect Wi-Fi and record recovery behaviour.
- [ ] Run 60 minutes; record dropped frames, bitrate, CPU, memory, phone battery and temperature.
- [ ] Repeat with no WAN/internet connection.
- [ ] Verify Windows remains responsive.

Do not mark a test passed without a real device and recorded result.
