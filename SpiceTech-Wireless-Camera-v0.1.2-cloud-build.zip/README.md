# SpiceTech Wireless Camera

**Prototype source package — v0.1.0 — 13 November 2026**

A free, local-network Android camera transmitter and Windows MediaMTX gateway for production workflows. Normal streaming is designed to work without internet access after the gateway binary has been installed.

## What is in this package

- `android-camera/`: Kotlin Android application (Android 11 / API 30 minimum) using RootEncoder for camera preview, H.264 encoding and RTMP publishing.
- `windows-companion/`: lightweight PowerShell WinForms companion. It downloads the official MediaMTX Windows x64 release once, starts/stops the local gateway, lists laptop IPv4 addresses and displays RTSP URLs.
- `gateway/mediamtx.yml`: local RTMP ingest and RTSP/TCP output configuration.
- `shared/connection-protocol/`: stream topology, URLs, ports and initial profile.
- `enhancement-engine/`: honest implementation status and staged plan.
- `tests/`: physical acceptance checklist.

## Current prototype scope

Implemented in source:
- Android camera preview using RootEncoder's Camera2 pipeline.
- Manual Windows IPv4 entry.
- RTMP publishing target `rtmp://WINDOWS-IP:1935/cam1`.
- 720p, 25 fps, 2 Mbps video encoder request.
- Start/stop streaming and front/rear camera switch.
- MediaMTX configuration for RTMP ingest and RTSP/TCP output.
- Windows gateway start/stop UI, local IPv4 listing and RTSP URL listing.

Not implemented yet: QR pairing, automatic discovery, background foreground-service streaming, audio, advanced camera controls, automatic reconnection policy, adaptive bitrate, multi-phone UI, enhancement filters, AI super-resolution, 4K output, signed Windows installer.

## Network design

Phone publishes RTMP/TCP to Windows port `1935`. OBS/vMix reads RTSP/TCP from Windows port `8554`. For camera 1:

`rtsp://WINDOWS-IP:8554/cam1`

The RTSP output is configured for TCP interleaving to simplify private-LAN firewall traversal. MediaMTX relays compressed video; it does not transcode it.

MediaMTX supports cross-protocol publish/read, and its RTSP documentation lists H.264 support. vMix documents RTSP over TCP/UDP input support. OBS requires the VLC Video Source for this RTSP workflow; OBS documentation says this source requires VLC to be installed (64-bit VLC for 64-bit OBS). The exact installed OBS/VLC combination still needs a physical test.

## Windows setup

1. On the HP laptop, press `Win + R`, type `winver`, press Enter. Record the Windows 10 version, OS build and edition. This is required before choosing a compiled companion runtime or installer.
2. Extract this ZIP to a normal folder, e.g. `Documents\\SpiceTech-Wireless-Camera`.
3. Connect the laptop to the local Wi-Fi router or phone hotspot. Internet is only needed on first gateway launch to download the official MediaMTX release. After that, the gateway binary is local.
4. Double-click `windows-companion\\Run-SpiceTech.bat`.
5. Press **START GATEWAY**. Select/record the laptop's Wi-Fi IPv4 address shown in the window.
6. If Windows Firewall blocks connections, run `Install-Firewall-Rules.ps1` from an elevated PowerShell window while the Wi-Fi profile is Private. This adds only TCP 1935 and 8554 inbound rules scoped to LocalSubnet and Private profile. It does not disable the firewall.

The first-run download requires internet. For a fully offline first install, obtain the official MediaMTX Windows AMD64 archive separately and place its `mediamtx.exe` in `gateway\\mediamtx.exe` before launching the companion.

## Android build

The development container used to prepare this source had Java 21 but did not have Android SDK, Gradle, ADB or Android Studio. No APK was produced or tested here.

Build prerequisites on a build machine:
- JDK 17 (recommended for the Android Gradle Plugin used here).
- Android SDK Platform 35 and Build Tools installed.
- Gradle 8.9 or compatible with Android Gradle Plugin 8.7.3.
- Internet for the first dependency resolution (Google Maven, Maven Central and JitPack).

From the project root, run:

```bash
gradle assembleDebug
```

The APK, if the build succeeds, will be at:

`android-camera/app/build/outputs/apk/debug/app-debug.apk`

Install with Android platform tools:

```bash
adb install -r android-camera/app/build/outputs/apk/debug/app-debug.apk
```

The source currently targets API 35 and requires Android 11 (API 30) or later. RootEncoder 2.8.2 is an Apache-2.0 project and provides Camera2, H.264 and RTMP functionality. Dependency resolution and API compatibility must be verified by a real Gradle build before calling this compiled.

## Phone operation

1. Ensure phone and laptop are on the same Wi-Fi network. The router does not need internet access.
2. Open SpiceTech Wireless Camera and grant camera permission.
3. Enter the laptop's Wi-Fi IPv4 address.
4. Press **START STREAM**.
5. In OBS or vMix, add a network stream using `rtsp://WINDOWS-IP:8554/cam1`.
6. Press **STOP STREAM** when finished.

This prototype is foreground-only. Do not leave the app or lock the phone during the first test; lifecycle-safe background streaming is a later milestone.

## Troubleshooting

- **No connection:** confirm both devices use the same Wi-Fi subnet; re-check the laptop IPv4; ensure gateway is running.
- **Gateway download fails:** download MediaMTX Windows AMD64 from the official project release page while online, extract `mediamtx.exe` into `gateway`.
- **Firewall:** set the trusted Wi-Fi network to Private; use the narrowly scoped firewall script. Never turn Windows Firewall off globally.
- **Client/AP isolation:** some guest Wi-Fi networks prevent devices from communicating. Use a normal private SSID or hotspot with client isolation disabled.
- **Weak Wi-Fi:** move closer to the access point, use 5 GHz where stable, and reduce bitrate/resolution if later controls are available.
- **RTSP does not open:** confirm RTSP URL and TCP 8554 reachability. In vMix choose Stream > RTSP over TCP. In OBS install 64-bit VLC, then add a VLC Video Source and enter the RTSP URL. OBS documents that VLC Video Source requires VLC to be installed.

## Honest verification report

| Item | Status |
|---|---|
| Source files created | Yes |
| ZIP archive | Created; archive integrity check passed |
| Android APK compiled | No — Android SDK/Gradle unavailable in build environment |
| Windows companion compiled | No — PowerShell source, no compiled executable |
| MediaMTX binary bundled | No — network unavailable in build environment; companion fetches official release on first run |
| Static source/config inspection | XML parsed; YAML parsed; ZIP integrity passed; PowerShell/Kotlin compilation not run |
| Physical Android 11 test | Not performed |
| Physical Windows 10 test | Not performed |
| OBS/vMix test | Not performed |
| 60-minute/offline/reconnect test | Not performed |

## Licensing

RootEncoder is Apache-2.0. MediaMTX is distributed under MIT (verify the exact release's included licence when packaging the binary). This source package does not bundle third-party binaries. Preserve third-party notices in any future distribution.
