# Enhancement engine — status

No enhancement filters are enabled in v0.1. The first milestone deliberately sends the camera's encoded H.264 stream without CPU/GPU post-processing.

Planned stages, in priority order:
1. Pass-through (implemented by the absence of a transcode stage).
2. Optional scaling and conservative sharpening on the Android GPU.
3. Lightweight noise reduction and colour controls after profiling supported phones.
4. Adaptive quality governor using encoder/network/thermal telemetry.
5. AI super-resolution only after per-device benchmarking; never required for streaming.

4K is not implemented. A 4K RTSP container/setting will not be presented as genuine 4K camera detail. Upscaling cannot recreate sensor detail absent from the source.
