package com.spicetech.wirelesscamera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.view.SurfaceHolder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.pedro.library.rtmp.RtmpCamera2
import com.pedro.library.view.OpenGlView
import com.pedro.common.ConnectChecker

/** First vertical slice: foreground camera preview and RTMP video publishing. */
class MainActivity : AppCompatActivity(), ConnectChecker {
    private lateinit var camera: RtmpCamera2
    private lateinit var ipField: EditText
    private lateinit var urlLabel: TextView
    private lateinit var status: TextView
    private lateinit var start: Button
    private val permissionRequest = 41
    private var streaming = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val preview = findViewById<OpenGlView>(R.id.cameraPreview)
        ipField = findViewById(R.id.serverIp)
        urlLabel = findViewById(R.id.streamUrl)
        status = findViewById(R.id.statusText)
        start = findViewById(R.id.startButton)
        camera = RtmpCamera2(preview, this)
        preview.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = Unit
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                camera.replaceView(preview)
                if (!camera.isStreaming) camera.startPreview()
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (camera.isStreaming) camera.stopStream()
                camera.stopPreview()
            }
        })

        ipField.setText(getSharedPreferences("settings", MODE_PRIVATE)
            .getString("server_ip", "192.168.18.2"))
        updateUrl()
        ipField.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) updateUrl() }
        start.setOnClickListener { beginStream() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopStream() }
        findViewById<Button>(R.id.switchButton).setOnClickListener {
            if (camera.isStreaming) camera.switchCamera()
            else status.text = "Start preview/stream before switching camera"
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), permissionRequest)
        }
    }

    private fun updateUrl() {
        val ip = ipField.text.toString().trim()
        urlLabel.text = "rtmp://$ip:1935/cam1"
        getSharedPreferences("settings", MODE_PRIVATE).edit().putString("server_ip", ip).apply()
    }

    private fun beginStream() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), permissionRequest)
            return
        }
        val ip = ipField.text.toString().trim()
        if (ip.isBlank() || ip.contains(" ")) { status.text = "Enter a valid laptop IP address"; return }
        updateUrl()
        if (camera.isStreaming) return
        val prepared = camera.prepareVideo(1280, 720, 25, 2_000_000, 0)
        if (!prepared) { status.text = "This phone could not prepare the requested video encoder"; return }
        camera.startStream("rtmp://$ip:1935/cam1")
        status.text = "Connecting to $ip …"
        start.isEnabled = false
    }

    private fun stopStream() {
        if (::camera.isInitialized && camera.isStreaming) camera.stopStream()
        streaming = false
        start.isEnabled = true
        status.text = "Stream stopped"
    }

    override fun onConnectionStarted(url: String) { runOnUiThread { status.text = "Connecting…" } }
    override fun onConnectionSuccess() { runOnUiThread { streaming = true; status.text = "LIVE — video publishing"; start.isEnabled = false } }
    override fun onConnectionFailed(reason: String) { runOnUiThread { streaming = false; status.text = "Connection failed: $reason"; start.isEnabled = true; if (camera.isStreaming) camera.stopStream() } }
    override fun onNewBitrate(bitrate: Long) { runOnUiThread { status.text = "LIVE — ${(bitrate / 1000)} kbps" } }
    override fun onDisconnect() { runOnUiThread { streaming = false; status.text = "Disconnected"; start.isEnabled = true } }
    override fun onAuthError() { runOnUiThread { status.text = "Gateway authentication error"; start.isEnabled = true } }
    override fun onAuthSuccess() { runOnUiThread { status.text = "Gateway authentication successful" } }

    override fun onResume() { super.onResume() }
    override fun onPause() { if (::camera.isInitialized) { if (camera.isStreaming) camera.stopStream(); camera.stopPreview() }; super.onPause() }
    override fun onDestroy() { if (::camera.isInitialized) camera.stopPreview(); super.onDestroy() }
}
