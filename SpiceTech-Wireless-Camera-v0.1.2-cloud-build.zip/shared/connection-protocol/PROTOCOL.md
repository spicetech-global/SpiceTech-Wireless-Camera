# SpiceTech Wireless Camera — local protocol v0.1

## Topology
- Windows runs MediaMTX on the local network.
- Android publishes H.264 over RTMP/TCP to `rtmp://<WINDOWS_IPV4>:1935/<camera-id>`.
- Production applications read RTSP/TCP from `rtsp://<WINDOWS_IPV4>:8554/<camera-id>`.
- No cloud endpoint, account, internet connection, or remote relay is involved in the media path.

## Camera identifiers
Prototype paths: `cam1` through `cam4`. Each phone must use a unique path. The initial Android UI publishes `cam1` only; multi-camera assignment is not yet implemented.

## Initial media profile
- Video: H.264/AVC
- Resolution: 1280 × 720
- Frame rate: 25 fps
- Target bitrate: 2,000,000 bit/s
- Audio: disabled in prototype
- RTSP transport: TCP interleaved, to reduce LAN firewall complexity

## Ports
- TCP 1935: Android RTMP publisher → Windows gateway
- TCP 8554: OBS/vMix RTSP reader → Windows gateway

## Addressing and discovery
v0.1 uses manual IPv4 entry. Automatic discovery, QR pairing, device identity and authentication are future milestones. Keep the gateway on a trusted private LAN; do not expose ports to the public internet.
