# Android build status

- Android source project: present.
- GitHub Actions workflow: added at `.github/workflows/android-apk.yml`.
- Default Windows gateway IP: set to `192.168.18.2`.
- APK: **not built or tested yet**. This environment has no Android SDK/Gradle installation and cannot fetch Android dependencies.

## Cloud build

Push this project to a GitHub repository, then open **Actions → Build Android APK → Run workflow**. On success, download the `spicetech-wireless-camera-debug-apk` artifact. A successful cloud compilation still does not prove physical camera streaming; that requires installing the APK and testing against the running MediaMTX gateway.
